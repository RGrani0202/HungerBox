import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ShopdataService {

  constructor() { }
  shops(){
    return [
      {name: 'Subway',star:4.7},
      {name: 'Burgerking',star:4.77},
      {name: 'Pizza hut',star:4.78},
      {name: 'Dominos',star:4.77},
    ]
  }
}
