import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import {ShopdataService} from '../services/shopdata.service';
@Component({
  selector: 'app-cafe-items',
  templateUrl: './cafe-items.component.html',
  styleUrls: ['./cafe-items.component.css']
})
export class CafeItemsComponent implements OnInit {
  cafeName: string | null = null;

  constructor(private route: ActivatedRoute, private shopdata:ShopdataService) {
    console.warn("shopdata",shopdata.shops())
   }

  ngOnInit() {
    this.cafeName = this.route.snapshot.paramMap.get('cafeName');
  }
  
  
}
