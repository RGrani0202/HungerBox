import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { AboutComponent } from './about/about.component';
import { CustomerHomepageComponent } from './customer-homepage/customer-homepage.component';
import { CafeItemsComponent } from './cafe-items/cafe-items.component';

const routes: Routes = [

  {
    path:'about',
    component:AboutComponent
  },
  {
    path: 'home',
    component: CustomerHomepageComponent
  },
  {
    path: '',
    redirectTo:'/home', pathMatch:'full'
  },

  { path: 'cafe/:cafeName', component: CafeItemsComponent },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
